from django.contrib import admin
from models import UserProfile, Rating

admin.site.register(UserProfile)
admin.site.register(Rating)
